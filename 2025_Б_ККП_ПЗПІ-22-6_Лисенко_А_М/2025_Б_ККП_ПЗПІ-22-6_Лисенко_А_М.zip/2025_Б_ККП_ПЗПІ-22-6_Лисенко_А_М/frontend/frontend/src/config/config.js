export const BASE_URL = 'http://localhost:5000/api';

export const ICONS = {
  edit: 'https://i.postimg.cc/d1q4vKpP/edit.png',
  delete: 'https://i.postimg.cc/TwCQ34vy/delete.png',
  random: 'https://i.postimg.cc/VNBKkYQs/random.png',
  logo: 'https://i.postimg.cc/q7jMgfLd/logo.png'
};